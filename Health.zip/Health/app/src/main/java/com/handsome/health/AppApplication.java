package com.handsome.health;

import android.app.Application;

/**
 * Created by zjw on 2018/12/27.
 */
public class AppApplication extends Application {
    public static String account=null;//�˺�

    public void onCreate(){
        super.onCreate();
    }
}
